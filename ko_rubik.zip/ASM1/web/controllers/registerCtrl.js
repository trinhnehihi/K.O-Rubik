app.controller('registerCtrl', function($scope, $http, $rootScope, $location) {
    
    // Tải dữ liệu từ API http://localhost:3000/users
    $http.get('http://localhost:3000/users')
        .then(function(response) {
            // Lưu trữ dữ liệu trong một biến
            $scope.usersData = response.data;
            // Gán số lượng tài khoản vào $scope.userCount
            $scope.userCount = $scope.usersData.length;
        })
        .catch(function(error) {
            console.error('Lỗi khi tải dữ liệu từ API:', error);
        });

    $scope.register = function() {
        if ($scope.password !== $scope.confirm_password) {
            $scope.isError = true;
        } else {
            // Tăng biến đếm lên 1 và gán cho id của tài khoản mới
            var newUserId = ++$scope.userCount;
            
            $http.post('http://localhost:3000/users', {
                id: newUserId,
                name: $scope.name,
                email: $scope.email,
                password: $scope.password,
                name: $scope.name
            }).then(
                function(res) {
                    $location.path('/login');
                },
                function(err) {
                    $scope.isError = true;
                    console.error('Lỗi khi đăng ký người dùng:', err);
                }
            );
        }
    };
});
