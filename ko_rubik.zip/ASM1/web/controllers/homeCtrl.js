app.controller('homeCtrl', function ($scope, $http, $location, $rootScope) {
    
    $scope.dsSP = [];
    $http.get('http://localhost:3000/products').then(
        function (res) {
            $scope.dsSP = res.data;
        },
        function (res) {
            console.log('lỗi');
        }
    );
    
    $rootScope.addToCart = function (sp) {
        let inCart = false;
        // sản phẩm đã có trong giỏ hàng -> tăng số lượng
        $rootScope.cart.forEach(prod => {
            if (prod.id === sp.id) {
                inCart = true;
                prod.quantity++;
            }
        });
        // sản phẩm chưa có trong giỏ hàng -> thêm vào giỏ hàng
            if (!inCart) {
                sp.quantity = 1;
                $rootScope.cart.push(sp);
            }
            localStorage.setItem('cart', JSON.stringify($rootScope.cart));
        }
        $scope.limit = 8;
        $scope.cate="";
    });
