app.controller('cartCtrl', function ($scope, $rootScope, $location, $http) {

    $rootScope.tinhTong = function () {
        let tong = 0;
        if ($rootScope.cart) {
            $rootScope.cart.forEach(sp => {
                tong += sp.quantity * sp.price;
            });
        }

        return tong;
    }
    $scope.saveCart = function () {
        localStorage.setItem('cart', JSON.stringify($rootScope.cart));
    }
    $scope.delete = function (index) {
        $rootScope.cart.splice(index, 1);
        $scope.saveCart();
    }
    $scope.deleteAll = function () {
        $rootScope.cart = [];
        $scope.saveCart();
    }
    $scope.checkout = function () {
        $http.post(`http://localhost:3000/orders`, {
            name: $rootScope.name,
            idUser: "-1",
            phone: $rootScope.phone,
            address: $rootScope.address,
            products: $rootScope.cart,
            total: $scope.tinhTong(),
            date: new Date().toLocaleString('sv-SE'),
            status: 'Đang chờ xử lý',
        }).then(
            function (res) {
                alert('Đặt hàng thành công');

                // Tự động click vào nút đóng của Modal
                var closeButton = document.querySelector('#exampleModal .btn-close');
                if (closeButton) {
                    closeButton.click();
                }
                $scope.deleteAll();
                $location.path('/');
            }
        );
    }

})