app.controller('detailCtrl', function ($scope, $http, $routeParams, $rootScope) {
    $scope.detail = {};
    $http.get(`http://localhost:3000/products/${$routeParams.id}`).then(
        function (res) {
            $scope.detail = res.data;
            $scope.tintuc.view++;
            $http.patch(`http://localhost:3000/products/${$routeParams.id}`,
                {
                    view: $scope.detail.view
                }
            );
        },
        function (res) {
            console.log('lỗi');
        }
    );
    $scope.dsSP = [];
    $http.get('http://localhost:3000/products').then(
        function (res) {
            $scope.dsSP = res.data;
        },
        function (res) {
            console.log('lỗi');
        }
    );
    $scope.Date = function (date) {
        return new Date(date);
    };
    $scope.comment = function () {
        $http.post(`http://localhost:3000/comments`,
            {
                "idNews": $routeParams.id,
                "content": $scope.content,
                "idUser": $rootScope.user.id,
                "name": $rootScope.user.name,
                "date": new Date().toLocaleString('sv-SE'),
            }
        ).then(
            function (res) {
                $scope.content = '';
                $scope.loadComment();
            }
        )

    }
    $scope.deleteComment = function (id) {
        var deletecm = confirm('Bạn có chắc chắn muốn xóa bình luận này?');
        if (deletecm == true) {
            $http.delete(`http://localhost:3000/comments/${id}`).then(
                function (res) {
                    $scope.loadComment();
                }
            )
        }
    }
    $scope.dsBL = [];
    $scope.loadComment = function () {
        $http.get(`http://localhost:3000/comments?idNews=${$routeParams.id}`).then(
            function (res) {
                $scope.dsBL = res.data;
            },
            function (res) {
                console.log('lỗi');
            }
        )
    }
    $scope.loadComment();
});
