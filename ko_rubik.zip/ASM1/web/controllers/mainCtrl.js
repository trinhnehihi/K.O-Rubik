app.controller('mainCtrl', function($scope, $rootScope, $location) {
    if (localStorage.getItem('users') != null) {
        $rootScope.user = JSON.parse(localStorage.getItem('users'));
    }
    $scope.logout = function() {
        localStorage.removeItem('users');
        delete $rootScope.user;
        $location.path('/login');
    }
    if (localStorage.getItem('cart')) {
        $rootScope.cart = JSON.parse(localStorage.getItem('cart'));
    } else {
        $rootScope.cart = [];
    }
    $rootScope.getsl = function() {
        $rootScope.sl = 0;
        if ($rootScope.cart) {
            $rootScope.cart.forEach(sp => {
                $rootScope.sl += sp.quantity;
            });        
        }
        return  $rootScope.sl;
    }
})