var app = angular.module('myapp', ['ngRoute']);
app.config(function($routeProvider) {
    $routeProvider
    .when('/', {
        templateUrl: 'views/home.html',
        controller: 'homeCtrl'
    })
    .when('/detail/:id', {
        templateUrl: 'views/detail.html',
        controller: 'detailCtrl'
    })
    .when('/cart', {
        templateUrl: 'views/cart.html',
        controller: 'cartCtrl'
    })
    .when('/login', {
        templateUrl: 'views/login.html',
        controller: 'loginCtrl'
    })
    .when('/register', {
        templateUrl: 'views/register.html',
        controller: 'registerCtrl'
    })
    .otherwise({
        template: 'ERROR 404'
    })
});